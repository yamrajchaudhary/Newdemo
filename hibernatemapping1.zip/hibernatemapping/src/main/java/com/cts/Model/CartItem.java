/*Author: Janam Gupta
 *Date Created: 06-02-2020
 *Description: Hibernate Mapping one to one unidirection
 * */
package com.cts.Model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
@Entity
public class CartItem implements Serializable{
	@Id
	@GeneratedValue
	private int cartItemId;
	private String description;
	private int prodId;
	public CartItem() {
	
	}
	
	
	@Override
	public String toString() {
		return "CartItem [cartItemId=" + cartItemId + ", description=" + description + ", prodId=" + prodId + "]";
	}


	public CartItem(int cartItemId, String description, int prodId) {
		super();
		this.cartItemId = cartItemId;
		this.description = description;
		this.prodId = prodId;
	}


	public int getCartItemId() {
		return cartItemId;
	}
	public void setCartItemId(int cartItemId) {
		this.cartItemId = cartItemId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getProdId() {
		return prodId;
	}
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}	
	
	
}
