/*Author: Janam Gupta
 *Date Created: 06-02-2020
 *Description: Hibernate Mapping one to one bidirection
 * */
package com.cts.hibernatemappingdemo2;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cts.Model.Cart;
import com.cts.Model.CartItem;

public class HibernateMappingDemo {

	public static void main(String[] args) {
		Configuration configuration = new Configuration().configure();
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		CartItem cartItem = new CartItem("This is PRoduct 1", 1001);
		session.save(cartItem);
		Cart cart = new Cart(1002,cartItem);
		session.save(cart);
		session.getTransaction().commit();
		
		int cartId = cart.getCartId();
		int cartItemId = cartItem.getCartItemId();
		Session sessionget = sessionFactory.openSession();
		sessionget.beginTransaction();
		Cart cartGet = (Cart)sessionget.get(Cart.class,cartId);
		CartItem cartItemGet = (CartItem)sessionget.get(CartItem.class,cartItemId);
		System.out.println(cartGet.getCartId());
		System.out.println(cartItemGet.getCart().getCartId());
		System.out.println(cartGet.getCartItem().getDescription());
		System.out.println(cartGet.getCartItem().getCartItemId());
		sessionget.getTransaction().commit();
		session.close();
		sessionget.close();
	}

}
