/*Author: Janam Gupta
 *Date Created: 06-02-2020
 *Description: Hibernate Mapping one to one bidirection
 * */
package com.cts.Model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
@Entity
public class Cart implements Serializable{
	@Id
	@GeneratedValue
	private int cartId;
	private int userId;
	@OneToOne
	private CartItem cartItem;
	public Cart() {
		// TODO Auto-generated constructor stub
	}
	
	
	public Cart(int userId, CartItem cartItem) {
		super();
		//this.cartId = cartId;
		this.userId = userId;
		this.cartItem = cartItem;
	}


	public int getCartId() {
		return cartId;
	}


	public void setCartId(int cartId) {
		this.cartId = cartId;
	}


	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public CartItem getCartItem() {
		return cartItem;
	}
	public void setCartItem(CartItem cartItem) {
		this.cartItem = cartItem;
	}
	
	
}
