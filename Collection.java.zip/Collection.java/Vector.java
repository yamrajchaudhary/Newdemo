package com.cts.javaDay5;

import java.util.*; 

public class TestVector { 
    public static void main(String[] arg) 
    { 
  
        // create default vector 
        Vector v = new Vector(); 
  
        v.add(1); 
        v.add(2); 
        v.add("geeks"); 
        v.add("forGeeks"); 
        v.add(3); 
  
        System.out.println("Vector is " + v); 
    } 
}